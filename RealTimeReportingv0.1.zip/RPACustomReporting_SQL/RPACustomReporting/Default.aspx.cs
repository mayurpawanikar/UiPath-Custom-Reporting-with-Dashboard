﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Web;
using System.Drawing;
using System.Configuration;

namespace RPACustomReporting
{
    public partial class Default : System.Web.UI.Page
    {
        string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            // The Page is accessed for the first time. 
            if (!IsPostBack)
            {
                // Enable the GridView paging option and  
                // specify the page size. 
                dataTable.AllowPaging = true;
                dataTable.PageSize = 10;


                // Enable the GridView sorting option. 
                dataTable.AllowSorting = true;


                // Initialize the sorting expression. 
                ViewState["SortExpression"] = "ProcessName ASC";

                GetProcessName();
                // Populate the GridView. 
                BindGridView();
                //populateData();

            }
            
        }

        private void BindGridView()
        {
            try
            {
                SqlConnection con = new SqlConnection(connStr);
                //con.Open();
                SqlCommand cmd = new SqlCommand("select * from UIPathProcessReport where TransactionName is not null order by TransactionID DESC", con);
                SqlDataAdapter olda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                olda.Fill(dt);


                dataTable.DataSource = dt;
                dataTable.DataBind();
                olda.Dispose();
                cmd.Dispose();
                //System.Threading.Thread.Sleep(10000);
                //con.Close();
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        // GridView.RowDataBound Event 
        protected void dataTable_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            // Make sure the current GridViewRow is a data row. 
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // Make sure the current GridViewRow is either  
                // in the normal state or an alternate row. 
                if (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate)
                {
                    // Add client-side confirmation when deleting. 
                    //((LinkButton)e.Row.Cells[1].Controls[0]).Attributes["onclick"] = "if(!confirm('Are you certain you want to delete this person ?')) return false;";
                }
            }
        }


        // GridView.PageIndexChanging Event 
        protected void dataTable_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            // Set the index of the new display page.  
            dataTable.PageIndex = e.NewPageIndex;


            // Rebind the GridView control to  
            // show data in the new page. 
            DateTime StartTime, EndTime;
            try
            {
                string strsql = string.Empty;
                SqlConnection con = new SqlConnection(connStr);
                //con.Open();
                SqlCommand cmd = new SqlCommand("Select * from UIPathProcessReport", con);
                if (drpProcesssName.SelectedValue == "All")
                {
                    if (StartDt.Text == string.Empty && EndDt.Text == string.Empty)
                    {
                        cmd.CommandText = "select * from UIPathProcessReport where TransactionName is not null order by TransactionID DESC";
                    }
                    else
                    {
                        StartTime = DateTime.ParseExact(StartDt.Text, "MM/dd/yyyy", null);
                        EndTime = DateTime.ParseExact(EndDt.Text, "MM/dd/yyyy", null);
                        cmd.CommandText = "select * from UIPathProcessReport where StartTime between @StartDate AND @EndTime AND TransactionName is not null order by TransactionID DESC";
                        cmd.Parameters.AddWithValue("@StartDate", StartTime.Date);
                        cmd.Parameters.AddWithValue("@EndTime", EndTime.Date.AddDays(1));
                    }

                }
                else
                {
                    if (StartDt.Text == string.Empty && EndDt.Text == string.Empty)
                    {
                        cmd.CommandText = "select * from UIPathProcessReport where ProcessName=" + "'" + drpProcesssName.SelectedValue + "' AND TransactionName is not null order by TransactionID DESC";
                    }
                    else
                    {
                        StartTime = DateTime.ParseExact(StartDt.Text, "MM/dd/yyyy", null);
                        EndTime = DateTime.ParseExact(EndDt.Text, "MM/dd/yyyy", null);
                        cmd.CommandText = "select * from UIPathProcessReport where ProcessName=" + "'" + drpProcesssName.SelectedValue + "' AND StartTime between @StartDate AND @EndTime AND TransactionName is not null order by TransactionID DESC";
                        cmd.Parameters.AddWithValue("@StartDate", StartTime.Date);
                        cmd.Parameters.AddWithValue("@EndTime", EndTime.Date.AddDays(1));
                    }

                }

                SqlDataAdapter olda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                olda.Fill(dt);


                dataTable.DataSource = dt;
                dataTable.DataBind();
                olda.Dispose();
                cmd.Dispose();
                //System.Threading.Thread.Sleep(10000);
                //con.Close();
            }
            catch (Exception)
            {

                throw;
            }
        }

        // GridView.Sorting Event 
        protected void dataTable_Sorting(object sender, GridViewSortEventArgs e)
        {
            string[] strSortExpression = ViewState["SortExpression"].ToString().Split(' ');


            // If the sorting column is the same as the previous one,  
            // then change the sort order. 
            if (strSortExpression[0] == e.SortExpression)
            {
                if (strSortExpression[1] == "ASC")
                {
                    ViewState["SortExpression"] = e.SortExpression + " " + "DESC";
                }
                else
                {
                    ViewState["SortExpression"] = e.SortExpression + " " + "ASC";
                }
            }
            // If sorting column is another column,   
            // then specify the sort order to "Ascending". 
            else
            {
                ViewState["SortExpression"] = e.SortExpression + " " + "ASC";
            }


            // Rebind the GridView control to show sorted data. 
            BindGridView();
        }

        private void GetProcessName()
        {
            try
            {
                string strsql = "SELECT DISTINCT ProcessName FROM UIPathProcessReport";
                SqlConnection con = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand(strsql, con);
                SqlDataAdapter olda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                olda.Fill(dt);

                drpProcesssName.DataTextField = Convert.ToString(dt.Columns["ProcessName"]);
                drpProcesssName.DataValueField = Convert.ToString(dt.Columns["TransactionID"]);
                drpProcesssName.DataSource = dt;
                drpProcesssName.DataBind();
                drpProcesssName.Items.Insert(0, new ListItem("All", "All"));
                cmd.Dispose();
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        protected void drpProcesssName_SelectedIndexChanged(object sender, EventArgs e)
        {
            DateTime StartTime, EndTime;
            try
            {
                string strsql = string.Empty;
                SqlConnection con = new SqlConnection(connStr);
                //con.Open();
                SqlCommand cmd = new SqlCommand("Select * from UIPathProcessReport", con);
                if (drpProcesssName.SelectedValue == "All")
                {
                    if (StartDt.Text == string.Empty && EndDt.Text == string.Empty)
                    {
                        cmd.CommandText = "select * from UIPathProcessReport where TransactionName is not null order by TransactionID DESC";
                    }
                    else
                    {
                        StartTime = DateTime.ParseExact(StartDt.Text, "MM/dd/yyyy", null);
                        EndTime = DateTime.ParseExact(EndDt.Text, "MM/dd/yyyy", null);
                        cmd.CommandText = "select * from UIPathProcessReport where StartTime between @StartDate AND @EndTime AND TransactionName is not null order by TransactionID DESC";
                        cmd.Parameters.AddWithValue("@StartDate", StartTime.Date);
                        cmd.Parameters.AddWithValue("@EndTime", EndTime.Date.AddDays(1));
                    }
                    
                }
                else
                {
                    if (StartDt.Text == string.Empty && EndDt.Text == string.Empty)
                    {
                        cmd.CommandText = "select * from UIPathProcessReport where ProcessName=" + "'" + drpProcesssName.SelectedValue + "' AND TransactionName is not null order by TransactionID DESC";
                    }
                    else
                    {
                        StartTime = DateTime.ParseExact(StartDt.Text, "MM/dd/yyyy", null);
                        EndTime = DateTime.ParseExact(EndDt.Text, "MM/dd/yyyy", null);
                        cmd.CommandText = "select * from UIPathProcessReport where ProcessName=" + "'" + drpProcesssName.SelectedValue + "' AND StartTime between @StartDate AND @EndTime AND TransactionName is not null order by TransactionID DESC";
                        cmd.Parameters.AddWithValue("@StartDate", StartTime.Date);
                        cmd.Parameters.AddWithValue("@EndTime", EndTime.Date.AddDays(1));
                    }
                        
                }
                
                SqlDataAdapter olda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                olda.Fill(dt);


                dataTable.DataSource = dt;
                dataTable.DataBind();
                olda.Dispose();
                cmd.Dispose();
                //System.Threading.Thread.Sleep(10000);
                //con.Close();
            }
            catch (Exception)
            {

                throw;
            }
        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            DateTime StartTime, EndTime;
            try
            {
                string strsql = string.Empty;
                //strsql = StartDt.Text;
                if (StartDt.Text != String.Empty && EndDt.Text != String.Empty)
                {
                    StartTime = DateTime.ParseExact(StartDt.Text, "MM/dd/yyyy", null);
                    EndTime = DateTime.ParseExact(EndDt.Text, "MM/dd/yyyy", null);
                }
                else
                {
                    StartTime = new DateTime(2019, 1, 1);
                    EndTime = DateTime.Now.Date;

                }
                SqlConnection con = new SqlConnection(connStr);
                //con.Open();
                SqlCommand cmd = new SqlCommand("Select * from UIPathProcessReport", con);
                if (drpProcesssName.SelectedValue == "All")
                {
                    cmd.CommandText = "select * from UIPathProcessReport where StartTime between @StartDate AND @EndTime AND TransactionName is not null order by TransactionID DESC";                    
                }
                else
                {
                    cmd.CommandText = "select * from UIPathProcessReport where ProcessName=" + "'" + drpProcesssName.SelectedValue + "' AND StartTime between @StartDate AND @EndTime AND TransactionName is not null order by TransactionID DESC";
                }
                cmd.Parameters.AddWithValue("@StartDate", StartTime.Date);
                cmd.Parameters.AddWithValue("@EndTime", EndTime.Date.AddDays(1));
                SqlDataAdapter olda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                olda.Fill(dt);


                dataTable.DataSource = dt;
                dataTable.DataBind();
                olda.Dispose();
                cmd.Dispose();
                //System.Threading.Thread.Sleep(10000);
                //con.Close();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            //required to avoid the run time error "  
            //Control 'GridView1' of type 'Grid View' must be placed inside a form tag with runat=server."  
        }

        private void BindGridviewExcel()
        {
            DateTime StartTime, EndTime;
            try
            {
                string strsql = string.Empty;
                SqlConnection con = new SqlConnection(connStr);
                //con.Open();
                SqlCommand cmd = new SqlCommand("Select * from UIPathProcessReport", con);
                if (drpProcesssName.SelectedValue == "All")
                {
                    if (StartDt.Text == string.Empty && EndDt.Text == string.Empty)
                    {
                        cmd.CommandText = "select * from UIPathProcessReport where TransactionName is not null order by TransactionID DESC";
                    }
                    else
                    {
                        StartTime = DateTime.ParseExact(StartDt.Text, "MM/dd/yyyy", null);
                        EndTime = DateTime.ParseExact(EndDt.Text, "MM/dd/yyyy", null);
                        cmd.CommandText = "select * from UIPathProcessReport where StartTime between @StartDate AND @EndTime AND TransactionName is not null order by TransactionID DESC";
                        cmd.Parameters.AddWithValue("@StartDate", StartTime.Date);
                        cmd.Parameters.AddWithValue("@EndTime", EndTime.Date.AddDays(1));
                    }

                }
                else
                {
                    if (StartDt.Text == string.Empty && EndDt.Text == string.Empty)
                    {
                        cmd.CommandText = "select * from UIPathProcessReport where ProcessName=" + "'" + drpProcesssName.SelectedValue + "' AND TransactionName is not null order by TransactionID DESC";
                    }
                    else
                    {
                        StartTime = DateTime.ParseExact(StartDt.Text, "MM/dd/yyyy", null);
                        EndTime = DateTime.ParseExact(EndDt.Text, "MM/dd/yyyy", null);
                        cmd.CommandText = "select * from UIPathProcessReport where ProcessName=" + "'" + drpProcesssName.SelectedValue + "' AND StartTime between @StartDate AND @EndTime AND TransactionName is not null order by TransactionID DESC";
                        cmd.Parameters.AddWithValue("@StartDate", StartTime.Date);
                        cmd.Parameters.AddWithValue("@EndTime", EndTime.Date.AddDays(1));
                    }

                }

                SqlDataAdapter olda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                olda.Fill(dt);


                dataTable.DataSource = dt;
                dataTable.DataBind();
                olda.Dispose();
                cmd.Dispose();
                //System.Threading.Thread.Sleep(10000);
                //con.Close();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void ExportGridToExcel()
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=CustomReport_" + drpProcesssName.SelectedValue + "_" + DateTime.Now + ".xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                dataTable.AllowPaging = false;
                this.BindGridviewExcel();

                dataTable.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in dataTable.HeaderRow.Cells)
                {
                    cell.BackColor = dataTable.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in dataTable.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = dataTable.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = dataTable.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                dataTable.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            ExportGridToExcel();
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            this.BindGridviewExcel();
        }
    }
}