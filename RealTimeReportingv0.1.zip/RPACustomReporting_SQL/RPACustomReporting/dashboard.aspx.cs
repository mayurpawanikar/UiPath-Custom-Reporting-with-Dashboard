﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace RPACustomReporting
{
    public partial class dashboard : System.Web.UI.Page
    {
        string avgtransactionperjob, numtransactionprocessed, numjobsprocessed, avgtransactionexecutiontime;
        Double BotUtilizationTime;
        string connStr = System.Configuration.ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            DateTime StartTime, EndTime;
            if (!IsPostBack)
            {
                GetProcessName();
                StartTime = new DateTime(2019, 1, 1);
                EndTime = DateTime.Now.Date;
                ShowData("ALL",StartTime,EndTime);
            }
        }

        protected void BtnSubmit_Click(object sender, EventArgs e)
        {
            DateTime StartTime, EndTime;
            if (StartDt.Text != String.Empty && EndDt.Text != String.Empty)
            {
                StartTime = DateTime.ParseExact(StartDt.Text, "MM/dd/yyyy", null);
                EndTime = DateTime.ParseExact(EndDt.Text, "MM/dd/yyyy", null);
                
            }
            else {
                StartTime =new DateTime(2019,1,1);
                EndTime = DateTime.Now.Date;

            }

            ShowData(drpProcesssName.SelectedValue, StartTime, EndTime);
        }

        private void ShowData(string Processname,DateTime StartTime,DateTime EndTime)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    //Number of transactions processed


                    using (SqlCommand cmd = new SqlCommand("TRANSACTIONSTATS", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@PROCESSNAME", Processname);
                        cmd.Parameters.AddWithValue("@STARTTIME", StartTime.Date);        
                        cmd.Parameters.AddWithValue("@ENDTIME", EndTime.Date.AddDays(1));
                        cmd.Parameters.Add("@NUMBEROFSUCCESSFULTRANSACTION", SqlDbType.Decimal);
                        cmd.Parameters["@NUMBEROFSUCCESSFULTRANSACTION"].Direction = ParameterDirection.Output;
                        cmd.Parameters.Add("@NUMBEROFFAULTEDTRANSACTION", SqlDbType.Decimal);
                        cmd.Parameters["@NUMBEROFFAULTEDTRANSACTION"].Direction = ParameterDirection.Output;
                        cmd.Parameters.Add("@NUMBEROFINPROGRESSTRANSACTION", SqlDbType.Decimal);
                        cmd.Parameters["@NUMBEROFINPROGRESSTRANSACTION"].Direction = ParameterDirection.Output;
                        cmd.Parameters.Add("@NUMBEROFRULEEXCEPTIONSTRANSACTION", SqlDbType.Decimal);
                        cmd.Parameters["@NUMBEROFRULEEXCEPTIONSTRANSACTION"].Direction = ParameterDirection.Output;
                        cmd.ExecuteNonQuery();

                        SuccessFulTransactionCount.Value = Convert.ToString(cmd.Parameters["@NUMBEROFSUCCESSFULTRANSACTION"].Value);
                        FaultedTransactionCount.Value = Convert.ToString(cmd.Parameters["@NUMBEROFFAULTEDTRANSACTION"].Value);
                        RuleExceptionTransactionCount.Value = Convert.ToString(cmd.Parameters["@NUMBEROFRULEEXCEPTIONSTRANSACTION"].Value);
                        InProgressTransactionCount.Value = Convert.ToString(cmd.Parameters["@NUMBEROFINPROGRESSTRANSACTION"].Value);

                    }
                        using (SqlCommand cmd = new SqlCommand("NUMBEROFTRANSACTIONPROCESSED", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@PROCESSNAME", Processname);
                            cmd.Parameters.AddWithValue("@STARTTIME",StartTime.Date);        
                            cmd.Parameters.AddWithValue("@ENDTIME", EndTime.Date.AddDays(1));
                            cmd.Parameters.Add("@NUMBEROFTRANSACTIONPROCESSED", SqlDbType.Int);
                            cmd.Parameters["@NUMBEROFTRANSACTIONPROCESSED"].Direction = ParameterDirection.Output;
                            cmd.ExecuteNonQuery();
                        numtransactionprocessed = Convert.ToString(cmd.Parameters["@NUMBEROFTRANSACTIONPROCESSED"].Value);
                        if (numtransactionprocessed == "NA")
                        {
                            NUMBEROFTRANSACTIONPROCESSEDlbl.Text = numtransactionprocessed;
                        }
                        else
                        {
                            NUMBEROFTRANSACTIONPROCESSEDlbl.Text = numtransactionprocessed + " Transaction(s)";
                        }
                        }

                        using (SqlCommand cmd = new SqlCommand("NUMBEROFJOBSPROCESSED", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@PROCESSNAME", Processname);
                            cmd.Parameters.AddWithValue("@STARTTIME", StartTime.Date);        
                            cmd.Parameters.AddWithValue("@ENDTIME", EndTime.Date.AddDays(1));
                            cmd.Parameters.Add("@NUMBEROFJOBSPROCESSED", SqlDbType.Int);
                            cmd.Parameters["@NUMBEROFJOBSPROCESSED"].Direction = ParameterDirection.Output;
                            cmd.ExecuteNonQuery();
                            numjobsprocessed = Convert.ToString(cmd.Parameters["@NUMBEROFJOBSPROCESSED"].Value);
                        if (numjobsprocessed == "NA")
                        {
                            NUMBEROFJOBSPROCESSEDlbl.Text = numjobsprocessed;
                        }
                        else
                        {
                            NUMBEROFJOBSPROCESSEDlbl.Text = numjobsprocessed + " Job(s)";
                        }
                        }

                        using (SqlCommand cmd = new SqlCommand("AVGTRANSACTIONEXECUTIONTIME", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@PROCESSNAME", Processname);
                            cmd.Parameters.AddWithValue("@STARTTIME", StartTime.Date);
                            cmd.Parameters.AddWithValue("@ENDTIME", EndTime.Date.AddDays(1));

                        avgtransactionexecutiontime= Convert.ToString(cmd.ExecuteScalar());
                        if (avgtransactionexecutiontime == "NA")
                        {
                            AVGTRANSACTIONEXECUTIONTIMELbl.Text = avgtransactionexecutiontime;
                        }
                        else
                        {
                            AVGTRANSACTIONEXECUTIONTIMELbl.Text = avgtransactionexecutiontime + " Minute(s)";
                        }

                        }

                        using (SqlCommand cmd = new SqlCommand("AVGTRANSACTIONPERJOB", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@PROCESSNAME", Processname);
                            cmd.Parameters.AddWithValue("@STARTTIME", StartTime.Date);
                            cmd.Parameters.AddWithValue("@ENDTIME", EndTime.Date.AddDays(1));


                        avgtransactionperjob = Convert.ToString(cmd.ExecuteScalar());
                        if (avgtransactionperjob == "NA")
                        {
                            AverageJobsPerTransactionLbl.Text = avgtransactionperjob;
                        }
                        else
                        {
                            AverageJobsPerTransactionLbl.Text = avgtransactionperjob + " Transaction(s)";
                        }

                        }

                    using (SqlCommand cmd = new SqlCommand("BOTUTILIZATION", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@PROCESSNAME", Processname);
                        cmd.Parameters.AddWithValue("@STARTTIME", StartTime.Date);
                        cmd.Parameters.AddWithValue("@ENDTIME", EndTime.Date.AddDays(1));
                        cmd.Parameters.Add("@TIMECONSUMED", SqlDbType.Int);
                        cmd.Parameters["@TIMECONSUMED"].Direction = ParameterDirection.Output;
                        cmd.ExecuteNonQuery();

                        if (cmd.Parameters["@TIMECONSUMED"].Value != DBNull.Value)
                        {
                            BotUtilizationTime = Convert.ToDouble(cmd.Parameters["@TIMECONSUMED"].Value);
                            TimeSpan t = TimeSpan.FromSeconds(BotUtilizationTime);

                            string answer = string.Format("{0:D2}(H) {1:D2}(M) {2:D2}(S) {3:D3}(MS)",
                                            t.Hours,
                                            t.Minutes,
                                            t.Seconds,
                                            t.Milliseconds);

                            lblBOTUtilizationTime.Text = answer;
                        }
                        else
                        {
                            lblBOTUtilizationTime.Text = "No Data";
                        }


                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void GetProcessName()
        {
            try
            {
                string strsql = "SELECT DISTINCT ProcessName FROM UIPathProcessReport";
                SqlConnection con = new SqlConnection(connStr);
                SqlCommand cmd = new SqlCommand(strsql, con);
                SqlDataAdapter olda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                olda.Fill(dt);

                drpProcesssName.DataTextField = Convert.ToString(dt.Columns["ProcessName"]);
                drpProcesssName.DataValueField = Convert.ToString(dt.Columns["TransactionID"]);
                drpProcesssName.DataSource = dt;
                drpProcesssName.DataBind();
                drpProcesssName.Items.Insert(0, new ListItem("All","ALL"));
                cmd.Dispose();
            }
            catch (Exception)
            {

                throw;
            }

        }

        protected void drpProcesssName_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string ProcessName = string.Empty;
                DateTime StartTime, EndTime;
                if (StartDt.Text != String.Empty && EndDt.Text != String.Empty)
                {
                    StartTime = DateTime.ParseExact(StartDt.Text, "MM/dd/yyyy", null);
                    EndTime = DateTime.ParseExact(EndDt.Text, "MM/dd/yyyy", null);

                }
                else
                {
                    StartTime = new DateTime(2019, 1, 1);
                    EndTime = DateTime.Now.Date;

                }

                ShowData(drpProcesssName.SelectedValue, StartTime, EndTime);
            }
            catch (Exception)
            {

                throw;
            }
            
        }
        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            DateTime StartTime, EndTime;
            if (StartDt.Text != String.Empty && EndDt.Text != String.Empty)
            {
                StartTime = DateTime.ParseExact(StartDt.Text, "MM/dd/yyyy", null);
                EndTime = DateTime.ParseExact(EndDt.Text, "MM/dd/yyyy", null);

            }
            else
            {
                StartTime = new DateTime(2019, 1, 1);
                EndTime = DateTime.Now.Date;

            }

            this.ShowData(drpProcesssName.SelectedValue, StartTime, EndTime);
        }
    }
}